#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
pluginPath=/www/server/panel/plugin/kazhan
dataFile=/www/server/panel/data/kazhan.json

Install_kazhan()
{
	mkdir -p $pluginPath
	mkdir -p /www/server/panel/data
	# 覆盖安装会把插件目录里的空 config.json 解压进来。有外部副本时把已部署记录拷回来。
	restore=0
	if [ ! -f "$pluginPath/config.json" ]; then
		restore=1
	elif ! grep -q '"domain"' "$pluginPath/config.json"; then
		restore=1
	fi
	if [ "$restore" = 1 ] && [ -f "$dataFile" ] && grep -q '"domain"' "$dataFile"; then
		cp -f "$dataFile" "$pluginPath/config.json"
	fi
	if [ ! -f "$pluginPath/config.json" ]; then
		echo '{"sites":[],"payments":[]}' > "$pluginPath/config.json"
	fi
	chmod 600 "$pluginPath/config.json"
	# 插件目录里仍有记录时，同步到目录外，供下次覆盖安装恢复
	if grep -q '"domain"' "$pluginPath/config.json"; then
		cp -f "$pluginPath/config.json" "$dataFile"
		chmod 600 "$dataFile"
	fi
	echo '安装完成' > $install_tmp
}

Uninstall_kazhan()
{
	# 只卸插件页面，不删已部署的网站、守护进程，以及目录外的部署记录
	rm -rf $pluginPath
}

if [ "${1}" = 'install' ] || [ "${1}" = 'update' ]; then
	Install_kazhan
elif [ "${1}" = 'uninstall' ]; then
	Uninstall_kazhan
fi

#!/bin/bash
# 安装宝塔「进程守护管理器」：下载官方插件包，再执行其 install.sh。
# 官方脚本把依赖写死在 python3.7 目录时，再用当前面板的 btpip 补装。
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin
export PATH

plugin=/www/server/panel/plugin/supervisor
version="${1:-3.0.6}"
case "$version" in
	''|*[!0-9.]*) version=3.0.6 ;;
esac

log() { echo "[$(date '+%H:%M:%S')] $*"; }

read_node() {
	local f line
	for f in /www/server/panel/data/node_url.pl /www/server/panel/data/down_url.pl; do
		if [ -s "$f" ]; then
			line=$(head -n 1 "$f" | tr -d '\r\n ')
			line=${line%/}
			if [ -n "$line" ]; then
				echo "$line"
				return
			fi
		fi
	done
}

download_zip() {
	local url="$1"
	local show="${url%%\?*}"
	log "下载插件包 $show"
	rm -f /tmp/supervisor_plugin.zip
	if command -v wget >/dev/null 2>&1; then
		wget -q -O /tmp/supervisor_plugin.zip --timeout=30 --tries=2 "$url" || return 1
	else
		curl -fsSL --connect-timeout 20 --max-time 180 -o /tmp/supervisor_plugin.zip "$url" || return 1
	fi
	unzip -t /tmp/supervisor_plugin.zip >/dev/null 2>&1
}

unpack_to_plugin() {
	rm -rf /tmp/supervisor_unpack
	mkdir -p /tmp/supervisor_unpack
	unzip -o /tmp/supervisor_plugin.zip -d /tmp/supervisor_unpack >/dev/null || return 1
	local src=""
	if [ -f /tmp/supervisor_unpack/install.sh ]; then
		src=/tmp/supervisor_unpack
	elif [ -f /tmp/supervisor_unpack/supervisor/install.sh ]; then
		src=/tmp/supervisor_unpack/supervisor
	else
		src=$(find /tmp/supervisor_unpack -maxdepth 3 -name install.sh | head -n 1)
		src=$(dirname "$src")
	fi
	if [ -z "$src" ] || [ ! -f "$src/install.sh" ]; then
		log "压缩包里没有 install.sh"
		return 1
	fi
	mkdir -p "$plugin"
	cp -a "$src"/. "$plugin"/
	log "插件文件已放到 $plugin"
}

fetch_package() {
	if [ -s /tmp/supervisor_plugin.zip ] && unzip -t /tmp/supervisor_plugin.zip >/dev/null 2>&1; then
		log "使用已下载的插件包"
		unpack_to_plugin && return 0
	fi
	log "没有带账号信息的插件包，匿名地址通常会被拒绝"
	return 1
}

ensure_binary() {
	if [ -x /www/server/panel/pyenv/bin/supervisord ] || command -v supervisord >/dev/null 2>&1; then
		return 0
	fi
	log "安装脚本没有产出 supervisord，改用当前环境的 pip 补装"
	if command -v btpip >/dev/null 2>&1; then
		btpip install 'setuptools<82.0.0' || true
		btpip install 'supervisor==4.2.4' 'pyasynchat' -I || return 1
	elif [ -x /www/server/panel/pyenv/bin/pip ]; then
		/www/server/panel/pyenv/bin/pip install 'setuptools<82.0.0' || true
		/www/server/panel/pyenv/bin/pip install 'supervisor==4.2.4' 'pyasynchat' -I || return 1
	else
		return 1
	fi
}

write_unit_and_start() {
	local bin ctl py unit
	bin=/www/server/panel/pyenv/bin/supervisord
	ctl=/www/server/panel/pyenv/bin/supervisorctl
	py=/www/server/panel/pyenv/bin/python
	if [ ! -x "$bin" ]; then
		bin=$(command -v supervisord)
		ctl=$(command -v supervisorctl)
		py=$(command -v python3 || command -v python)
	fi
	if [ -z "$bin" ] || [ ! -x "$bin" ]; then
		log "找不到 supervisord"
		return 1
	fi
	mkdir -p /etc/supervisor "$plugin/log" "$plugin/profile" /var/log /var/run
	if [ ! -s /etc/supervisor/supervisord.conf ] && [ -f "$plugin/sample.conf" ]; then
		cp "$plugin/sample.conf" /etc/supervisor/supervisord.conf
	fi
	if [ -d /usr/lib/systemd/system ]; then
		unit=/usr/lib/systemd/system/supervisord.service
	else
		unit=/lib/systemd/system/supervisord.service
	fi
	cat > "$unit" <<EOF
[Unit]
Description=Process Monitoring and Control Daemon
After=network.target

[Service]
Type=forking
ExecStart=$py $bin -c /etc/supervisor/supervisord.conf
ExecStop=$ctl shutdown
ExecReload=$ctl reload
KillMode=process
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF
	systemctl daemon-reload
	systemctl enable supervisord >/dev/null 2>&1 || true
	systemctl restart supervisord
	sleep 1
	if pgrep -x supervisord >/dev/null 2>&1 || pgrep -f "$bin" >/dev/null 2>&1; then
		log "安装完成，进程守护服务已启动（$bin）"
		return 0
	fi
	log "进程守护服务没有启动，请执行 systemctl status supervisord 查看原因"
	return 1
}

log "开始安装进程守护管理器 $version"
if [ ! -f "$plugin/install.sh" ]; then
	fetch_package || { log "插件包下载失败"; exit 1; }
else
	log "目录里已有 install.sh，直接安装运行环境"
fi

if [ -f "$plugin/install.sh" ]; then
	bash "$plugin/install.sh" install || log "官方 install.sh 返回非 0，继续检查是否已装上"
else
	log "缺少 $plugin/install.sh"
	exit 1
fi

ensure_binary || { log "supervisord 安装失败"; exit 1; }
write_unit_and_start

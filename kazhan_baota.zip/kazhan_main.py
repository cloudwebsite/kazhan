# coding: utf-8
# 卡栈宝塔一键部署：检测/安装进程守护管理器，创建网站并写入守护进程。

import gzip
import hashlib
import json
import os
import re
import secrets
import shutil
import sys
import tarfile
import threading
import time
import urllib.request
import zipfile

import public

SUPERVISOR_DIR = '/www/server/panel/plugin/supervisor'
SUPERVISOR_MAIN = SUPERVISOR_DIR + '/supervisor_main.py'
SUPERVISOR_BIN = '/www/server/panel/pyenv/bin/supervisord'
SUPERVISOR_CTL = '/www/server/panel/pyenv/bin/supervisorctl'
SUPERVISOR_PROFILE = SUPERVISOR_DIR + '/profile/'
INSTALL_LOG = '/tmp/kazhan_supervisor_install.log'
INSTALL_LOCK = '/tmp/kazhan_supervisor_install.lock'
PLUGIN_DIR = '/www/server/panel/plugin/kazhan'
CONFIG_FILE = PLUGIN_DIR + '/config.json'
# 放在插件目录外，覆盖安装解压时不会被空配置换掉
DATA_FILE = '/www/server/panel/data/kazhan.json'
NGINX_VHOST = '/www/server/panel/vhost/nginx/'
SOFT_LIST_FILES = (
    '/www/server/panel/data/soft_list.json',
    '/www/server/panel/data/plugin_list.json',
    '/www/server/panel/data/list.json',
    '/www/server/panel/config/soft_list.json',
)
# 与后台在线更新同一批线路：直连和加速同时探测，取最快
RELEASE_REPO = 'cloudwebsite/kazhan'
RELEASE_ACCELS = (
    'https://gh-proxy.com',
    'https://ghfast.top',
    'https://ghproxy.net',
)
# 收款网关发行包。名称是对接的支付程序，不是本插件的出品方。
PAY_REPO = 'v03413/BEpusdt'


class kazhan_main:
    def get_env(self, get):
        sup = self._supervisor_state()
        return {
            'supervisor': sup,
            'nginx': os.path.isfile('/www/server/nginx/sbin/nginx'),
            'users': self._user_list(),
            'release': getattr(self, '_release_cache', None) or {},
            'sites': self._load_sites(),
            'payments': self._load_payments(),
            'install_log': self._tail_log(40) if sup.get('installing') or not sup.get('ready') else '',
        }

    def install_supervisor(self, get):
        """交给面板 install_plugin。不要自己拼插件包地址，supervisor-3.0.6.zip 会 404。"""
        state = self._supervisor_state()
        if state['ready']:
            started = self._ensure_supervisor_running()
            if started['status']:
                return public.returnMsg(True, '进程守护管理器已安装，服务已启动')
            return started
        if state['installing']:
            return public.returnMsg(True, '进程守护管理器正在安装，请稍候')
        return self._call_install_plugin()

    def check_release(self, get):
        """探测发行线路并读取最新版本，供页面展示。"""
        info = self._resolve_release()
        if not info.get('status'):
            return info
        self._release_cache = {
            'source': info.get('source'),
            'version': info.get('version'),
            'arch': info.get('arch'),
            'latency_ms': info.get('latency_ms'),
        }
        return info

    def deploy(self, get):
        sup = self._supervisor_state()
        if not sup['ready']:
            if not sup['installing']:
                self.install_supervisor(get)
            return public.returnMsg(False, '进程守护管理器尚未就绪，正在安装。完成后请再点一次部署')
        if not os.path.isfile('/www/server/nginx/sbin/nginx'):
            return public.returnMsg(False, '未检测到 Nginx，请先在软件商店安装 Nginx')

        domain = self._host(getattr(get, 'domain', ''))
        if not domain:
            return public.returnMsg(False, '主域名不正确')
        extras = []
        for item in re.split(r'[\s,]+', str(getattr(get, 'domains', '') or '')):
            if not item or item.lower() == domain:
                continue
            host = self._host(item)
            if not host:
                return public.returnMsg(False, '附加域名不正确: ' + item)
            if host not in extras:
                extras.append(host)

        try:
            requested = int(str(getattr(get, 'port', '') or '0'))
        except Exception:
            return public.returnMsg(False, '端口必须是数字')

        if requested and (requested < 1024 or requested > 65535 or requested in (80, 443)):
            return public.returnMsg(False, '监听端口请使用 1024–65535，且不要用 80/443')

        slug = re.sub(r'[^a-z0-9_]', '_', domain)
        program = ('kazhan_' + slug)[:60].strip('_')
        if not program or program == 'kazhan':
            return public.returnMsg(False, '无法从域名生成守护进程名')

        raw_path = getattr(get, 'path', '') or getattr(get, 'webroot', '') or getattr(get, 'app_dir', '') or ('/www/wwwroot/' + domain)
        site_dir = self._safe_dir(raw_path, '/www/wwwroot/' + domain)
        if not site_dir:
            return public.returnMsg(False, '运行目录必须在 /www 或 /opt 下，且不能是盘符根')

        port, port_note = self._pick_port(requested, domain, site_dir)
        if not port:
            return public.returnMsg(False, '没有可用端口')

        user = str(getattr(get, 'run_user', '') or getattr(get, 'user', '') or 'www').strip()
        if not re.fullmatch(r'[a-z_][a-z0-9_-]{0,31}', user):
            return public.returnMsg(False, '启动用户不合法')
        if not self._user_exists(user):
            return public.returnMsg(False, '系统里没有用户 ' + user)

        steps = []
        if port_note:
            steps.append(port_note)
        os.makedirs(site_dir, 0o755, exist_ok=True)
        os.makedirs(site_dir + '/configs', 0o755, exist_ok=True)
        os.makedirs(site_dir + '/data', 0o755, exist_ok=True)

        binary = site_dir + '/kazhan'
        got = self._fetch_latest(binary)
        if not got.get('status'):
            return got
        steps.append('程序已就绪：{0}，线路 {1}'.format(got.get('version') or '最新版', got.get('source') or '发行源'))

        conf = site_dir + '/configs/config.yaml'
        if not os.path.isfile(conf):
            redis_prefix, redis_err = self._pick_redis_prefix(program, site_dir)
            if not redis_prefix:
                return public.returnMsg(False, redis_err or '无法分配 Redis 队列前缀')
            redis_addr, redis_password = self._local_redis()
            others = 0
            for site in self._load_sites():
                if os.path.abspath(str(site.get('path') or '')) != os.path.abspath(site_dir):
                    others += 1
            concurrency = self._worker_concurrency(others + 1)
            public.writeFile(conf, self._config_yaml(port, redis_addr, redis_password, redis_prefix, concurrency))
            os.chmod(conf, 0o600)
            steps.append('本站配置已写好。密钥已生成，请不要把配置文件传到公网')
            steps.append('本站队列前缀 {0}，和其他站分开；同时处理 {1} 个任务'.format(redis_prefix, concurrency))
        elif self._fill_empty_keys(conf):
            steps.append('已补上原来空着的密钥')
        else:
            steps.append('沿用已有配置，没有改密钥和端口')

        site_res = self._ensure_site(domain, extras, site_dir)
        if not site_res['status']:
            return site_res
        steps.append(site_res['msg'])

        ngx = self._write_proxy(domain, port)
        if not ngx['status']:
            return ngx
        steps.append('网站已反代到本站程序')
        public.serviceReload()

        public.ExecShell('chown -R {0}:{0} {1}'.format(user, self._shell_arg(site_dir)))
        self._chmod_run_dir(site_dir)
        if not self._chmod_binary(binary):
            return public.returnMsg(False, 'kazhan 未能设为 755，已停止写入进程守护')
        steps.append('程序已允许启动')

        run = self._ensure_supervisor_running()
        if not run['status']:
            return run
        daemon = self._write_daemon(program, user, site_dir, binary, domain)
        if not daemon['status']:
            return daemon
        steps.append(daemon['msg'])

        row = {
            'domain': domain,
            'domains': [domain] + extras,
            'port': port,
            'path': site_dir,
            'webroot': site_dir,
            'app_dir': site_dir,
            'program': program,
            'user': user,
            'site_id': site_res.get('site_id', 0),
        }
        sites = [s for s in self._load_sites() if s.get('domain') != domain and s.get('program') != program]
        sites.append(row)
        self._save_sites(sites)
        return {'status': True, 'msg': '部署完成，请打开 http://{0}/install 完成向导'.format(domain), 'steps': steps, 'site': row}

    def deploy_bepusdt(self, get):
        """安装 BEpusdt：下载解压、改权限、伪静态反代，最后写入进程守护。"""
        sup = self._supervisor_state()
        if not sup['ready']:
            if not sup['installing']:
                self.install_supervisor(get)
            return public.returnMsg(False, '进程守护管理器尚未就绪，正在安装。完成后请再点一次安装')
        if not os.path.isfile('/www/server/nginx/sbin/nginx'):
            return public.returnMsg(False, '未检测到 Nginx，请先在软件商店安装 Nginx')

        domain = self._host(getattr(get, 'domain', ''))
        if not domain:
            return public.returnMsg(False, '主域名不正确')
        extras = []
        for item in re.split(r'[\s,]+', str(getattr(get, 'domains', '') or '')):
            if not item or item.lower() == domain:
                continue
            host = self._host(item)
            if not host:
                return public.returnMsg(False, '附加域名不正确: ' + item)
            if host not in extras:
                extras.append(host)

        try:
            requested = int(str(getattr(get, 'port', '') or '0'))
        except Exception:
            return public.returnMsg(False, '端口必须是数字')
        if requested and (requested < 1024 or requested > 65535 or requested in (80, 443)):
            return public.returnMsg(False, '监听端口请使用 1024–65535，且不要用 80/443')

        slug = re.sub(r'[^a-z0-9_]', '_', domain)
        program = ('bepusdt_' + slug)[:60].strip('_')
        if not program or program == 'bepusdt':
            return public.returnMsg(False, '无法从域名生成守护进程名')

        raw_path = getattr(get, 'path', '') or ('/www/wwwroot/' + domain)
        site_dir = self._safe_dir(raw_path, '/www/wwwroot/' + domain)
        if not site_dir:
            return public.returnMsg(False, '运行目录必须在 /www 或 /opt 下，且不能是盘符根')

        port, port_note = self._pick_pay_port(requested, domain, site_dir)
        if not port:
            return public.returnMsg(False, '没有可用端口')

        user = str(getattr(get, 'run_user', '') or getattr(get, 'user', '') or 'www').strip()
        if not re.fullmatch(r'[a-z_][a-z0-9_-]{0,31}', user):
            return public.returnMsg(False, '启动用户不合法')
        if not self._user_exists(user):
            return public.returnMsg(False, '系统里没有用户 ' + user)

        steps = []
        if port_note:
            steps.append(port_note)
        os.makedirs(site_dir, 0o755, exist_ok=True)
        os.makedirs(site_dir + '/data', 0o755, exist_ok=True)
        os.makedirs(site_dir + '/logs', 0o755, exist_ok=True)

        binary = site_dir + '/bepusdt'
        got = self._fetch_bepusdt(binary)
        if not got.get('status'):
            return got
        steps.append('收款程序已就绪：{0}，线路 {1}'.format(got.get('version') or '最新版', self._source_label(got.get('source'))))

        env_file = site_dir + '/.env'
        if not os.path.isfile(env_file):
            public.writeFile(env_file, self._pay_env(port, site_dir))
            os.chmod(env_file, 0o600)
            steps.append('收款配置已写好，只在本机监听')
        else:
            steps.append('沿用已有收款配置，没有改端口')

        site_res = self._ensure_site(domain, extras, site_dir)
        if not site_res['status']:
            return site_res
        steps.append(site_res['msg'])

        ngx = self._write_pay_proxy(domain, port)
        if not ngx['status']:
            return ngx
        steps.append('网站已反代到收款程序，配置和数据不能从外网下载')
        public.serviceReload()

        public.ExecShell('chown -R {0}:{0} {1}'.format(user, self._shell_arg(site_dir)))
        self._chmod_run_dir(site_dir)
        os.chmod(site_dir + '/logs', 0o755)
        if not self._chmod_binary(binary):
            return public.returnMsg(False, 'bepusdt 未能设为 755，已停止写入进程守护')
        steps.append('收款程序已允许启动')

        run = self._ensure_supervisor_running()
        if not run['status']:
            return run
        command = '{0} start --listen 127.0.0.1:{1} --sqlite {2}/data/sqlite.db --log {2}/logs'.format(binary, port, site_dir)
        daemon = self._write_daemon(program, user, site_dir, binary, domain, command, 'BEpusdt ' + domain)
        if not daemon['status']:
            return daemon
        steps.append(daemon['msg'])

        row = {
            'domain': domain,
            'domains': [domain] + extras,
            'port': port,
            'path': site_dir,
            'program': program,
            'user': user,
            'site_id': site_res.get('site_id', 0),
            'version': got.get('version') or '',
        }
        payments = [item for item in self._load_payments() if item.get('domain') != domain and item.get('program') != program]
        payments.append(row)
        self._save_payments(payments)
        return {
            'status': True,
            'msg': '收款网关已安装。到卡栈后台添加 BEpusdt 渠道，网关地址填 https://{0} 。API Token 只在第一次启动的进程日志里出现，请马上抄下来。'.format(domain),
            'steps': steps,
            'payment': row,
        }

    def restart_daemon(self, get):
        program = self._program_name(getattr(get, 'program', ''))
        if not program:
            return public.returnMsg(False, '进程名不正确')
        if not os.path.isfile(SUPERVISOR_PROFILE + program + '.ini'):
            return public.returnMsg(False, '守护进程不存在')
        run = self._ensure_supervisor_running()
        if not run['status']:
            return run
        self._chmod_binary(self._binary_from_ini(program))
        sup = self._supervisor_api()
        if not sup:
            return public.returnMsg(False, '无法连接进程守护管理器')
        stop = public.dict_obj()
        stop.program = program
        sup.StopProcess(stop)
        start = public.dict_obj()
        start.program = program
        res = sup.StartProcess(start)
        if isinstance(res, dict) and not res.get('status') and '已经启动' in str(res.get('msg', '')):
            return public.returnMsg(True, '进程已在运行')
        return res if isinstance(res, dict) else public.returnMsg(False, '重启失败')

    def remove_daemon(self, get):
        program = self._program_name(getattr(get, 'program', ''))
        if not program:
            return public.returnMsg(False, '进程名不正确')
        sup = self._supervisor_api()
        if sup and os.path.isfile(SUPERVISOR_PROFILE + program + '.ini'):
            args = public.dict_obj()
            args.program = program
            res = sup.RemoveProcess(args)
            if isinstance(res, dict) and not res.get('status'):
                return res
        sites = [s for s in self._load_sites() if s.get('program') != program]
        self._save_sites(sites)
        payments = [p for p in self._load_payments() if p.get('program') != program]
        self._save_payments(payments)
        return public.returnMsg(True, '已从进程守护中移除（网站和程序目录仍保留）')

    def run_install_job(self, version):
        """旧的后台入口。忽略传入的整段版本号，改走面板安装。"""
        result = self._call_install_plugin()
        msg = result.get('msg') if isinstance(result, dict) else result
        print(self._public_text(msg), flush=True)
        return 0 if isinstance(result, dict) and result.get('status') else 1

    def _call_install_plugin(self):
        """按软件商店的顺序：先 install_plugin，再 input_package。"""
        try:
            import panelPlugin
            installer = panelPlugin.panelPlugin()
        except Exception as exc:
            return public.returnMsg(False, '无法调用面板安装接口：' + self._public_text(exc))
        if not hasattr(installer, 'install_plugin') or not hasattr(installer, 'input_package'):
            return public.returnMsg(False, '当前面板没有安装接口')
        major, minor = self._supervisor_plugin_parts()
        args = public.dict_obj()
        args.sName = 'supervisor'
        args.version = str(major)
        args.min_version = str(minor)
        try:
            public.WriteFile(INSTALL_LOG, '提交 install_plugin sName=supervisor version={0} min_version={1}\n'.format(major, minor))
            public.WriteFile(INSTALL_LOCK, str(int(time.time())))
        except Exception:
            pass
        try:
            info = installer.install_plugin(args)
        except Exception as exc:
            msg = '安装进程守护失败：' + self._public_text(exc)
            self._append_install_log(msg)
            return public.returnMsg(False, msg)
        if isinstance(info, dict) and info.get('status') is False:
            msg = self._public_text(info.get('msg') or '面板拒绝安装')
            self._append_install_log(msg)
            return info
        if not isinstance(info, dict) or not info.get('tmp_path'):
            msg = '面板安装没有返回临时目录'
            self._append_install_log(msg)
            return public.returnMsg(False, msg)
        package = public.dict_obj()
        package.plugin_name = str(info.get('name') or 'supervisor')
        package.tmp_path = str(info.get('tmp_path'))
        package.install_opt = str(info.get('install_opt') or 'i')
        self._append_install_log('提交 input_package plugin_name={0} install_opt={1}'.format(package.plugin_name, package.install_opt))
        try:
            result = installer.input_package(package)
        except Exception as exc:
            msg = '面板安装失败：' + self._public_text(exc)
            self._append_install_log(msg)
            return public.returnMsg(False, msg)
        if not isinstance(result, dict):
            msg = '已提交面板安装进程守护管理器'
            self._append_install_log(msg)
            return public.returnMsg(True, msg)
        msg = self._public_text(result.get('msg') or result.get('message') or '')
        if msg:
            self._append_install_log(msg)
            result['msg'] = msg
        return result

    def _append_install_log(self, text):
        try:
            old = public.readFile(INSTALL_LOG) or ''
            public.WriteFile(INSTALL_LOG, old + str(text or '') + '\n')
        except Exception:
            pass

    def _public_text(self, text):
        text = str(text or '')
        text = re.sub(r'(access_key|secret_key|serverid|uid)=[^&\s]+', r'\1=***', text, flags=re.I)
        return text[:400]

    def _supervisor_version(self):
        """展示用完整版本，由 versions 里的 m_version 与 version 拼出来。"""
        major, minor = self._supervisor_soft_parts()
        return major + '.' + minor

    def _supervisor_plugin_parts(self):
        """安装参数直接用版本条目的两个字段，不再拆外层的 3.0.6。"""
        return self._supervisor_soft_parts()

    def _supervisor_soft_parts(self):
        """get_soft_list 的 list.data[].versions：m_version=3，version=0.6。"""
        cached = getattr(self, '_soft_parts', None)
        if cached:
            return cached
        pair = None
        try:
            pair = self._pick_soft_version(self._find_named_soft(self._query_soft_list(), 'supervisor'))
        except Exception:
            pair = None
        if not pair:
            for path in SOFT_LIST_FILES:
                pair = self._pair_from_file(path)
                if pair:
                    break
        if not pair:
            pair = ('3', '0.6')
        self._soft_parts = pair
        return pair

    def _query_soft_list(self):
        import panelPlugin
        plugin = panelPlugin.panelPlugin()
        args = public.dict_obj()
        args.type = '0'
        args.query = 'Supervisor'
        args.p = '1'
        args.row = '15'
        args.force = '0'
        data = plugin.get_soft_list(args)
        if isinstance(data, str):
            data = json.loads(data)
        return data

    def _pair_from_file(self, path):
        if not os.path.isfile(path):
            return None
        try:
            data = json.loads(public.readFile(path) or '')
        except Exception:
            return None
        return self._pick_soft_version(self._find_named_soft(data, 'supervisor'))

    def _find_named_soft(self, node, name):
        if isinstance(node, dict):
            if str(node.get('name') or '') == name and isinstance(node.get('versions'), list):
                return node
            for value in node.values():
                found = self._find_named_soft(value, name)
                if found:
                    return found
        elif isinstance(node, list):
            for item in node:
                found = self._find_named_soft(item, name)
                if found:
                    return found
        return None

    def _pick_soft_version(self, item):
        """取 update_time 最新的一条。外层 version=3.0.6 只是展示，不拿来安装。"""
        if not isinstance(item, dict):
            return None
        rows = item.get('versions')
        if not isinstance(rows, list):
            return None
        best = None
        best_time = -1
        for row in rows:
            if not isinstance(row, dict):
                continue
            major = str(row.get('m_version') or '').strip()
            minor = str(row.get('version') or '').strip()
            if not re.fullmatch(r'\d+', major) or not re.fullmatch(r'\d+(?:\.\d+)*', minor):
                continue
            try:
                stamp = int(row.get('update_time') or 0)
            except Exception:
                stamp = 0
            if best is None or stamp > best_time:
                best = (major, minor)
                best_time = stamp
        return best

    def _supervisor_bins(self):
        bins = []
        for path in (
            '/www/server/panel/pyenv/bin/supervisord',
            '/usr/local/bin/supervisord',
            '/usr/bin/supervisord',
        ):
            if os.path.isfile(path):
                bins.append(path)
        return bins

    def _supervisor_state(self):
        plugin = os.path.isfile(SUPERVISOR_MAIN)
        bins = self._supervisor_bins()
        binary = bool(bins)
        running = False
        if binary:
            ps = public.ExecShell("ps -ef | grep -E 'supervisord' | grep -v grep")[0]
            running = 'supervisord' in ps
        installing = self._install_busy() and not (plugin and binary)
        return {
            'ready': plugin and binary,
            'plugin': plugin,
            'binary': binary,
            'running': running,
            'installing': installing,
            'version': self._installed_supervisor_version() or self._supervisor_version(),
            'path': SUPERVISOR_DIR,
        }

    def _installed_supervisor_version(self):
        path = SUPERVISOR_DIR + '/info.json'
        if not os.path.isfile(path):
            return ''
        try:
            info = json.loads(public.readFile(path) or '')
        except Exception:
            return ''
        text = str(info.get('versions') or info.get('version') or '').strip()
        if re.fullmatch(r'\d+(?:\.\d+){1,3}', text):
            return text
        return ''

    def _install_busy(self):
        if not os.path.isfile(INSTALL_LOCK):
            return False
        try:
            started = int(public.readFile(INSTALL_LOCK).strip())
        except Exception:
            return False
        if time.time() - started > 600:
            return False
        ps = public.ExecShell("ps -ef | grep -E 'install_soft.sh|install_plugin|supervisor/install.sh' | grep -v grep")[0]
        return bool(ps.strip()) or (time.time() - started < 20)

    def _ensure_supervisor_running(self):
        state = self._supervisor_state()
        if not state['ready']:
            return public.returnMsg(False, '进程守护管理器未安装')
        if state['running']:
            return public.returnMsg(True, '进程守护服务已在运行')
        public.ExecShell('systemctl daemon-reload; systemctl enable supervisord; systemctl start supervisord')
        time.sleep(1)
        if self._supervisor_state()['running']:
            return public.returnMsg(True, '已启动进程守护服务')
        return public.returnMsg(False, '进程守护服务启动失败，请到软件商店打开进程守护管理器点启动')


    def _supervisor_api(self):
        if not os.path.isfile(SUPERVISOR_MAIN):
            return None
        if SUPERVISOR_DIR not in sys.path:
            sys.path.insert(0, SUPERVISOR_DIR)
        try:
            import supervisor_main
            return supervisor_main.supervisor_main()
        except Exception:
            return None

    def _daemon_get(self, fields):
        """进程守护的 AddProcess 会读 pjname/s，这里两种取法都填上。"""
        args = public.dict_obj()
        for key, value in fields.items():
            setattr(args, key, value)
        try:
            args.__dict__['pjname/s'] = fields.get('pjname', '')
        except Exception:
            pass
        return args

    def _write_daemon(self, program, user, app_dir, binary, domain, command=None, ps=None):
        if not self._chmod_binary(binary):
            return public.returnMsg(False, '程序不是 755，已停止写入进程守护')
        ini = SUPERVISOR_PROFILE + program + '.ini'
        if not command:
            command = '{0} serve -conf {1}/configs'.format(binary, app_dir)
        if not ps:
            ps = '卡栈 ' + domain
        fields = {
            'pjname': program,
            'user': user,
            'path': app_dir,
            'command': command,
            'numprocs': '1',
            'level': '999',
            'ps': ps,
        }
        sup = self._supervisor_api()
        res = None
        if sup:
            args = self._daemon_get(fields)
            try:
                if os.path.isfile(ini):
                    res = sup.UpdateProcess(args)
                else:
                    res = sup.AddProcess(args)
            except Exception:
                res = None
        if not isinstance(res, dict) or not res.get('status'):
            # 官方接口没写成时，按它的 ini / config.json 格式补写，进程守护页面仍能看到
            direct = self._write_profile(program, user, app_dir, command, ps)
            if not direct['status']:
                if isinstance(res, dict):
                    return res
                return direct
        else:
            start = public.dict_obj()
            start.program = program
            try:
                started = sup.StartProcess(start)
            except Exception:
                started = None
            if isinstance(started, dict) and not started.get('status'):
                if '已经启动' not in str(started.get('msg', '')):
                    return started
        return public.returnMsg(True, '已加入开机自启，服务已启动')

    def _write_profile(self, program, user, app_dir, command, ps):
        os.makedirs(SUPERVISOR_PROFILE, 0o755, exist_ok=True)
        os.makedirs(SUPERVISOR_DIR + '/log/', 0o755, exist_ok=True)
        body = (
            '[program:{name}]\n'
            'command={command}\n'
            'directory={directory}\n'
            'autorestart=true\n'
            'startsecs=3\n'
            'startretries=3\n'
            'stdout_logfile={log}{name}.out.log\n'
            'stderr_logfile={log}{name}.err.log\n'
            'stdout_logfile_maxbytes=2MB\n'
            'stderr_logfile_maxbytes=2MB\n'
            'user={user}\n'
            'priority=999\n'
            'numprocs=1\n'
            'process_name=%(program_name)s_%(process_num)02d\n'
        ).format(
            name=program,
            command=command,
            directory=app_dir,
            log=SUPERVISOR_DIR + '/log/',
            user=user,
        )
        public.writeFile(SUPERVISOR_PROFILE + program + '.ini', body)
        self._chmod_binary(app_dir.rstrip('/') + '/kazhan')
        conf_path = SUPERVISOR_DIR + '/config.json'
        try:
            current = json.loads(public.readFile(conf_path) or '[]')
        except Exception:
            current = []
        if not isinstance(current, list):
            current = []
        current = [item for item in current if item.get('program') != program]
        current.append({
            'program': program,
            'command': command,
            'directory': app_dir,
            'user': user,
            'priority': '999',
            'numprocs': '1',
            'runStatus': '',
            'ps': ps,
        })
        public.writeFile(conf_path, json.dumps(current))
        ctl = SUPERVISOR_CTL if os.path.isfile(SUPERVISOR_CTL) else 'supervisorctl'
        result = public.ExecShell('{0} update && {0} start {1}:'.format(ctl, program))
        text = ((result[0] or '') + (result[1] or '')).lower()
        if 'error' in text and 'already' not in text:
            self._ensure_supervisor_running()
            public.ExecShell('{0} update && {0} start {1}:'.format(ctl, program))
        return public.returnMsg(True, '已加入开机自启')

    def _ensure_site(self, domain, extras, webroot):
        find = public.M('sites').where('name=?', (domain,)).field('id,name,path').find()
        if not find or not find.get('id'):
            import panelSite
            args = public.dict_obj()
            args.webname = json.dumps({'domain': domain, 'domainlist': extras, 'count': len(extras)}, ensure_ascii=False)
            args.path = webroot
            args.type_id = 0
            args.type = 'PHP'
            args.version = '00'
            args.port = '80'
            args.ps = '卡栈 ' + domain
            args.ftp = 'false'
            args.sql = 'false'
            args.codeing = 'utf8mb4'
            created = panelSite.panelSite().AddSite(args)
            if isinstance(created, dict) and created.get('status') is False:
                return created
            find = public.M('sites').where('name=?', (domain,)).field('id,name,path').find()
            if not find or not find.get('id'):
                msg = created.get('msg') if isinstance(created, dict) else '创建网站失败'
                return public.returnMsg(False, msg)
            return {'status': True, 'msg': '已创建网站 ' + domain, 'site_id': find['id']}

        import panelSite
        site_obj = panelSite.panelSite()
        old_path = str(find.get('path') or '').rstrip('/')
        if old_path != webroot.rstrip('/'):
            moved = public.dict_obj()
            moved.id = find['id']
            moved.path = webroot
            try:
                if hasattr(site_obj, 'SetPath'):
                    site_obj.SetPath(moved)
            except Exception:
                pass
        for host in extras:
            add = public.dict_obj()
            add.id = find['id']
            add.webname = domain
            add.domain = host + ':80'
            try:
                site_obj.AddDomain(add)
            except Exception:
                pass
        return {'status': True, 'msg': '网站已存在，已核对域名', 'site_id': find['id']}

    def _chmod_run_dir(self, site_dir):
        """运行目录设为 755。目录已存在时 makedirs 不会改权限。"""
        for path in (site_dir, site_dir + '/configs', site_dir + '/data', site_dir + '/logs'):
            if os.path.isdir(path):
                os.chmod(path, 0o755)

    def _chmod_binary(self, binary):
        """建站会把网站目录里的文件改回 644，程序必须在那之后再设为 755。"""
        if not binary or not os.path.isfile(binary):
            return False
        os.chmod(binary, 0o755)
        public.ExecShell('chmod 755 ' + self._shell_arg(binary))
        return (os.stat(binary).st_mode & 0o111) == 0o111

    def _binary_from_ini(self, program):
        text = public.readFile(SUPERVISOR_PROFILE + program + '.ini') or ''
        matched = re.search(r'(?m)^command=(\S+)', text)
        return matched.group(1) if matched else ''

    def _proxy_rules(self, port):
        return (
            '#kazhan-START\n'
            'client_max_body_size 64m;\n'
            'location = /kazhan { return 404; }\n'
            'location ^~ /configs/ { return 404; }\n'
            'location ^~ /data/ { return 404; }\n'
            'location ^~ / {\n'
            '    proxy_pass http://127.0.0.1:%d;\n'
            '    proxy_http_version 1.1;\n'
            '    proxy_set_header Host $host;\n'
            '    proxy_set_header X-Real-IP $remote_addr;\n'
            '    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n'
            '    proxy_set_header X-Forwarded-Proto $scheme;\n'
            '    proxy_set_header Upgrade $http_upgrade;\n'
            '    proxy_set_header Connection "upgrade";\n'
            '}\n'
            '#kazhan-END\n'
        ) % port

    def _write_proxy(self, domain, port):
        """伪静态写到 vhost/rewrite，面板「伪静态」读的是这个文件。"""
        conf_file = NGINX_VHOST + domain + '.conf'
        conf = public.readFile(conf_file)
        if not conf:
            return public.returnMsg(False, '找不到网站 Nginx 配置: ' + conf_file)
        rewrite_dir = '/www/server/panel/vhost/rewrite'
        if not os.path.isdir(rewrite_dir):
            os.makedirs(rewrite_dir, 0o755)
        rewrite_file = rewrite_dir + '/' + domain + '.conf'
        block = self._proxy_rules(port)
        old = public.readFile(rewrite_file) or ''
        if '#kazhan-START' in old:
            rewrite = re.sub(r'#kazhan-START.*?#kazhan-END\n?', block, old, count=1, flags=re.S)
        elif old.strip():
            rewrite = old.rstrip() + '\n' + block
        else:
            rewrite = block
        public.writeFile(rewrite_file, rewrite)
        if '#kazhan-START' in conf:
            conf = re.sub(r'\n?\t?#kazhan-START.*?#kazhan-END\n?', '\n', conf, count=1, flags=re.S)
        include_line = 'include /www/server/panel/vhost/rewrite/{0}.conf;'.format(domain)
        if include_line not in conf:
            idx = conf.rfind('\n}')
            if idx < 0:
                return public.returnMsg(False, 'Nginx 配置结构无法识别')
            conf = conf[:idx] + '\n\t' + include_line + '\n' + conf[idx:]
        public.writeFile(conf_file, conf)
        test = public.ExecShell('/www/server/nginx/sbin/nginx -t')
        text = (test[0] or '') + (test[1] or '')
        if 'successful' not in text and 'ok' not in text.lower():
            return public.returnMsg(False, 'Nginx 配置检测未通过: ' + text[-300:])
        return public.returnMsg(True, 'ok')

    def _pay_proxy_rules(self, port):
        return (
            '#bepusdt-START\n'
            'client_max_body_size 16m;\n'
            'location = /bepusdt { return 404; }\n'
            'location = /.env { return 404; }\n'
            'location ^~ /data/ { return 404; }\n'
            'location ^~ /logs/ { return 404; }\n'
            'location ^~ / {\n'
            '    proxy_pass http://127.0.0.1:%d;\n'
            '    proxy_http_version 1.1;\n'
            '    proxy_set_header Host $host;\n'
            '    proxy_set_header X-Real-IP $remote_addr;\n'
            '    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n'
            '    proxy_set_header X-Forwarded-Proto $scheme;\n'
            '    proxy_set_header Upgrade $http_upgrade;\n'
            '    proxy_set_header Connection "upgrade";\n'
            '}\n'
            '#bepusdt-END\n'
        ) % port

    def _write_pay_proxy(self, domain, port):
        return self._write_marked_rewrite(domain, 'bepusdt', self._pay_proxy_rules(port))

    def _write_marked_rewrite(self, domain, marker, block):
        conf_file = NGINX_VHOST + domain + '.conf'
        conf = public.readFile(conf_file)
        if not conf:
            return public.returnMsg(False, '找不到网站 Nginx 配置: ' + conf_file)
        rewrite_dir = '/www/server/panel/vhost/rewrite'
        if not os.path.isdir(rewrite_dir):
            os.makedirs(rewrite_dir, 0o755)
        rewrite_file = rewrite_dir + '/' + domain + '.conf'
        start = '#' + marker + '-START'
        end = '#' + marker + '-END'
        old = public.readFile(rewrite_file) or ''
        if start in old:
            rewrite = re.sub(re.escape(start) + r'.*?' + re.escape(end) + r'\n?', block, old, count=1, flags=re.S)
        elif old.strip():
            rewrite = old.rstrip() + '\n' + block
        else:
            rewrite = block
        public.writeFile(rewrite_file, rewrite)
        if start in conf:
            conf = re.sub(r'\n?\t?' + re.escape(start) + r'.*?' + re.escape(end) + r'\n?', '\n', conf, count=1, flags=re.S)
        include_line = 'include /www/server/panel/vhost/rewrite/{0}.conf;'.format(domain)
        if include_line not in conf:
            idx = conf.rfind('\n}')
            if idx < 0:
                return public.returnMsg(False, 'Nginx 配置结构无法识别')
            conf = conf[:idx] + '\n\t' + include_line + '\n' + conf[idx:]
        public.writeFile(conf_file, conf)
        test = public.ExecShell('/www/server/nginx/sbin/nginx -t')
        text = (test[0] or '') + (test[1] or '')
        if 'successful' not in text and 'ok' not in text.lower():
            return public.returnMsg(False, 'Nginx 配置检测未通过: ' + text[-300:])
        return public.returnMsg(True, 'ok')

    def _machine_arch(self):
        machine = os.uname().machine if hasattr(os, 'uname') else ''
        machine = machine.lower()
        if machine in ('x86_64', 'amd64'):
            return 'amd64'
        if machine in ('aarch64', 'arm64'):
            return 'arm64'
        return ''

    def _probe_head(self, url, timeout=5):
        """收到任何 HTTP 响应即线路可达，不跟随重定向。"""
        class _NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                return None

        opener = urllib.request.build_opener(_NoRedirect)
        req = urllib.request.Request(url, method='HEAD')
        started = time.time()
        try:
            with opener.open(req, timeout=timeout) as resp:
                resp.read(64)
            return True, int((time.time() - started) * 1000)
        except Exception as exc:
            if getattr(exc, 'code', None):
                return True, int((time.time() - started) * 1000)
            return False, 0

    def _ranked_routes(self):
        """直连和加速线路同时探测，按延迟从快到慢排列。"""
        direct = 'https://github.com/{0}/releases/latest/download/update.json'.format(RELEASE_REPO)
        routes = [('github', direct)]
        for accel in RELEASE_ACCELS:
            routes.append((accel, accel.rstrip('/') + '/' + direct))
        hits = []
        lock = threading.Lock()

        def race(source, url):
            fine, ms = self._probe_head(url)
            if fine:
                with lock:
                    hits.append((ms, source, url))

        workers = [threading.Thread(target=race, args=item) for item in routes]
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join(8)
        hits.sort()
        return hits

    def _asset_url(self, source, version, asset):
        path = 'https://github.com/{0}/releases/download/{1}/{2}'.format(RELEASE_REPO, version, asset)
        if source == 'github':
            return path
        return source.rstrip('/') + '/' + path

    def _release_from_manifest(self, manifest, source, latency):
        arch = self._machine_arch()
        version = str((manifest or {}).get('version') or '').strip()
        if not re.fullmatch(r'v\d+\.\d+\.\d+', version):
            return None
        asset = 'kazhan-linux-' + arch
        chosen = None
        for item in manifest.get('files') or []:
            if isinstance(item, dict) and item.get('name') == asset:
                chosen = item
                break
        digest = str((chosen or {}).get('sha256') or '')
        if not chosen or not re.fullmatch(r'[0-9a-fA-F]{64}', digest):
            return None
        return {
            'status': True,
            'msg': '已选中线路',
            'source': source,
            'version': version,
            'arch': arch,
            'latency_ms': latency,
            'sha256': digest.lower(),
            'size': int(chosen.get('size') or 0),
            'asset_url': self._asset_url(source, version, asset),
        }

    def _resolve_release(self):
        arch = self._machine_arch()
        if not arch:
            return public.returnMsg(False, '只支持 amd64 / arm64')
        routes = self._ranked_routes()
        if not routes:
            return public.returnMsg(False, '所有发行线路都不可达，请检查服务器出网')
        tried = []
        for latency, source, manifest_url in routes:
            tried.append(self._source_label(source))
            try:
                manifest = self._http_json(manifest_url)
            except Exception:
                continue
            info = self._release_from_manifest(manifest, source, latency)
            if info:
                return info
        return public.returnMsg(False, '线路已切换仍读不到有效版本清单：' + '、'.join(tried))

    def _source_label(self, source):
        if source == 'github':
            return '直连'
        return str(source).replace('https://', '').replace('http://', '').rstrip('/')

    def _http_json(self, url):
        req = urllib.request.Request(url, headers={'User-Agent': 'kazhan-panel'})
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw = resp.read(1024 * 1024)
        return json.loads(raw.decode('utf-8'))

    def _fetch_latest(self, dest):
        arch = self._machine_arch()
        if not arch:
            return public.returnMsg(False, '只支持 amd64 / arm64')
        routes = self._ranked_routes()
        if not routes:
            return public.returnMsg(False, '所有发行线路都不可达，请检查服务器出网')
        errors = []
        for latency, source, manifest_url in routes:
            label = self._source_label(source)
            try:
                manifest = self._http_json(manifest_url)
            except Exception as exc:
                errors.append(label + ' 清单失败')
                continue
            info = self._release_from_manifest(manifest, source, latency)
            if not info:
                errors.append(label + ' 清单无效')
                continue
            err = self._download_checked(info, dest)
            if not err:
                self._release_cache = {
                    'source': info.get('source'),
                    'version': info.get('version'),
                    'arch': info.get('arch'),
                    'latency_ms': info.get('latency_ms'),
                }
                info['msg'] = '已通过 {0} 下载'.format(label)
                return info
            errors.append(label + ' ' + err)
        return public.returnMsg(False, '已切换全部线路仍失败：' + '；'.join(errors))

    def _download_checked(self, info, dest):
        tmp = dest + '.download'
        try:
            req = urllib.request.Request(info['asset_url'], headers={'User-Agent': 'kazhan-panel'})
            with urllib.request.urlopen(req, timeout=180) as resp, open(tmp, 'wb') as fh:
                while True:
                    chunk = resp.read(1024 * 64)
                    if not chunk:
                        break
                    fh.write(chunk)
        except Exception:
            if os.path.isfile(tmp):
                os.remove(tmp)
            return '下载失败'
        digest = hashlib.sha256()
        size = 0
        with open(tmp, 'rb') as fh:
            while True:
                block = fh.read(1024 * 1024)
                if not block:
                    break
                size += len(block)
                digest.update(block)
        if digest.hexdigest() != info['sha256'] or (info.get('size') and size != info['size']):
            os.remove(tmp)
            return '校验失败'
        staged = dest + '.pkg'
        os.replace(tmp, staged)
        try:
            err = self._place_program(staged, dest)
        finally:
            if os.path.isfile(staged):
                os.remove(staged)
        if err:
            if os.path.isfile(dest):
                os.remove(dest)
            return err
        if not self._chmod_binary(dest):
            return '程序权限未能设为 755'
        return ''

    def _place_program(self, package, dest):
        """压缩包解出 kazhan；已经是单个程序文件则直接就位。"""
        kind = self._package_kind(package)
        if kind == 'zip':
            return self._extract_zip(package, dest)
        if kind == 'gzip':
            return self._extract_gzip(package, dest)
        os.replace(package, dest)
        return ''

    def _package_kind(self, path):
        with open(path, 'rb') as fh:
            magic = fh.read(4)
        if magic[:2] == b'PK':
            return 'zip'
        if magic[:2] == b'\x1f\x8b':
            return 'gzip'
        return 'bin'

    def _program_name_in_archive(self, names):
        files = [name for name in names if name and not name.endswith('/')]
        for name in files:
            base = os.path.basename(name)
            if base == 'kazhan' or base.startswith('kazhan-linux-'):
                return name
        if len(files) == 1:
            return files[0]
        return ''

    def _extract_zip(self, package, dest):
        with zipfile.ZipFile(package) as zf:
            name = self._program_name_in_archive(zf.namelist())
            if not name or name.startswith('/') or '..' in name.split('/'):
                return '压缩包里没有 kazhan'
            with zf.open(name) as src, open(dest, 'wb') as out:
                shutil.copyfileobj(src, out)
        return ''

    def _extract_gzip(self, package, dest):
        try:
            with tarfile.open(package, 'r:gz') as tar:
                members = [item for item in tar.getmembers() if item.isfile() and not item.issym() and not item.islnk()]
                name = self._program_name_in_archive([item.name for item in members])
                if not name:
                    return '压缩包里没有 kazhan'
                picked = next((item for item in members if item.name == name), None)
                if not picked or picked.name.startswith('/') or '..' in picked.name.split('/'):
                    return '压缩包里没有 kazhan'
                src = tar.extractfile(picked)
                if src is None:
                    return '压缩包里没有 kazhan'
                with src, open(dest, 'wb') as out:
                    shutil.copyfileobj(src, out)
            return ''
        except tarfile.TarError:
            pass
        with gzip.open(package, 'rb') as src, open(dest, 'wb') as out:
            shutil.copyfileobj(src, out)
        return ''

    def _random_key(self):
        """32 字节真随机的 hex，与首启引导配置同一长度。"""
        return secrets.token_hex(32)

    def _fill_empty_keys(self, path):
        """四把密钥都是空字符串时补随机值。已有密钥不改。"""
        text = public.readFile(path) or ''
        names = ('jwt_admin_key', 'jwt_user_key', 'card_key', 'data_key')
        if not all(re.search(r'%s:\s*""' % name, text) for name in names):
            return False
        for name in names:
            text = re.sub(
                r'(%s:\s*)""' % name,
                lambda m, key=self._random_key(): m.group(1) + '"' + key + '"',
                text,
                count=1,
            )
        public.writeFile(path, text)
        os.chmod(path, 0o600)
        return True

    def _config_yaml(self, port, redis_addr, redis_password, redis_prefix, worker_concurrency):
        grpc = port + 1000 if port + 1000 <= 65535 else port + 1
        jwt_admin, jwt_user, card_key, data_key = (
            self._random_key(), self._random_key(), self._random_key(), self._random_key(),
        )
        redis_block = '  redis:\n    addr: {addr}\n'.format(addr=redis_addr)
        if redis_password:
            redis_block += '    password: {password}\n'.format(password=self._yaml_quote(redis_password))
        redis_block += (
            '    prefix: {prefix}\n'
            '    read_timeout: 0.2s\n'
            '    write_timeout: 0.2s\n'
            '  worker_concurrency: {concurrency}\n'
        ).format(prefix=redis_prefix, concurrency=worker_concurrency)
        # 密码里的花括号不能再被外层 format 吃掉
        redis_block = redis_block.replace('{', '{{').replace('}', '}}')
        return (
            'server:\n'
            '  http:\n'
            '    addr: 127.0.0.1:{port}\n'
            '    timeout: 30s\n'
            '  grpc:\n'
            '    addr: 127.0.0.1:{grpc}\n'
            '    timeout: 30s\n'
            '  migrate_on_start: true\n'
            '  admin_base_path: ""\n'
            'data:\n'
            '  database:\n'
            '    driver: sqlite\n'
            '    source: file:data/kazhan.db\n'
            '    max_open_conns: 20\n'
            '    max_idle_conns: 5\n'
            '{redis_block}'
            'security:\n'
            '  jwt_admin_key: "{jwt_admin}"\n'
            '  jwt_user_key: "{jwt_user}"\n'
            '  card_key: "{card_key}"\n'
            '  data_key: "{data_key}"\n'
            'tenancy:\n'
            '  mode: row\n'
            '  main_domain: ""\n'
            'log:\n'
            '  level: info\n'
            '  format: text\n'
        ).format(
            port=port, grpc=grpc, redis_block=redis_block,
            jwt_admin=jwt_admin, jwt_user=jwt_user,
            card_key=card_key, data_key=data_key,
        )

    def _yaml_quote(self, value):
        escaped = str(value).replace('\\', '\\\\').replace('"', '\\"')
        return '"' + escaped + '"'

    def _local_redis(self):
        """读取宝塔本机 Redis 的端口和 requirepass。没有配置文件时仍指向 127.0.0.1:6379。"""
        text = public.readFile('/www/server/redis/redis.conf') or ''
        port = '6379'
        matched = re.search(r'(?m)^\s*port\s+(\d+)\s*$', text)
        if matched:
            port = matched.group(1)
        password = ''
        matched = re.search(r'(?m)^\s*requirepass\s+(\S+)\s*$', text)
        if matched:
            password = matched.group(1).strip('"').strip("'")
            if password in ('""', "''"):
                password = ''
        return '127.0.0.1:' + port, password

    def _pick_redis_prefix(self, program, site_dir):
        """队列名前缀。asynq 键是 asynq:{队列名}，不能配全局键前缀，所以各实例用自己的队列名。"""
        base = re.sub(r'[^a-z0-9_]', '', str(program or '').lower())[:32] or 'kazhan'
        used = set()
        for site in self._load_sites():
            path = str(site.get('path') or '')
            if not path or os.path.abspath(path) == os.path.abspath(site_dir or ''):
                continue
            prefix = self._redis_prefix_in_config(path)
            if prefix:
                used.add(prefix)
        if base not in used:
            return base, ''
        for n in range(2, 100):
            candidate = (base[:28] + '_' + str(n))[:40]
            if candidate not in used:
                return candidate, ''
        return '', '无法分配不重复的 Redis 队列前缀'

    def _redis_prefix_in_config(self, site_dir):
        text = public.readFile(site_dir + '/configs/config.yaml') or ''
        matched = re.search(r'(?m)^\s*prefix:\s*([A-Za-z0-9_-]+)\s*$', text)
        if not matched:
            return ''
        return matched.group(1).lower()

    def _worker_concurrency(self, instance_count):
        """多实例同机时降低单进程消费并发，避免一起把 Redis 和 CPU 打满。"""
        if instance_count <= 1:
            return 5
        if instance_count <= 3:
            return 3
        return 2

    def _pick_port(self, requested, domain, site_dir):
        """多站点自动换端口。同一目录已有配置则沿用，避免把正在跑的端口改掉。"""
        existing = self._port_in_config(site_dir)
        if existing:
            return existing, ''
        if requested and not self._port_taken(requested, domain):
            if requested < 1024 or requested > 65535 or requested in (80, 443):
                return 0, ''
            return requested, ''
        start = requested if requested and requested not in (80, 443) else 8000
        if start < 1024:
            start = 8000
        port = self._free_port(start, domain)
        if not port:
            return 0, ''
        if requested and requested != port:
            note = '端口 {0} 已被占用，已改用 {1}（gRPC {2}）'.format(requested, port, self._grpc_port(port))
        else:
            note = '监听端口 {0}，gRPC {1}'.format(port, self._grpc_port(port))
        return port, note

    def _grpc_port(self, port):
        return port + 1000 if port + 1000 <= 65535 else port + 1

    def _port_in_config(self, site_dir):
        if not site_dir:
            return 0
        text = public.readFile(site_dir + '/configs/config.yaml') or ''
        matched = re.search(r'(?m)^\s*addr:\s*127\.0\.0\.1:(\d+)\s*$', text)
        if not matched:
            return 0
        try:
            return int(matched.group(1))
        except Exception:
            return 0

    def _saved_ports(self, ignore_domain):
        used = set()
        for site in self._load_sites():
            if ignore_domain and site.get('domain') == ignore_domain:
                continue
            try:
                http = int(site.get('port') or 0)
            except Exception:
                continue
            if not http:
                continue
            used.add(http)
            used.add(self._grpc_port(http))
            conf_port = self._port_in_config(str(site.get('path') or ''))
            if conf_port:
                used.add(conf_port)
                used.add(self._grpc_port(conf_port))
        for pay in self._load_payments():
            if ignore_domain and pay.get('domain') == ignore_domain:
                continue
            try:
                http = int(pay.get('port') or 0)
            except Exception:
                continue
            if http:
                used.add(http)
            env_port = self._pay_port_in_env(str(pay.get('path') or ''))
            if env_port:
                used.add(env_port)
        return used

    def _port_taken(self, port, ignore_domain):
        http = port
        grpc = self._grpc_port(port)
        used = self._saved_ports(ignore_domain)
        if http in used or grpc in used:
            return True
        return self._port_open(http) or self._port_open(grpc)

    def _free_port(self, start, ignore_domain):
        port = start
        while port < 65535:
            if port >= 1024 and port not in (80, 443) and not self._port_taken(port, ignore_domain):
                return port
            port += 1
        return 0

    def _port_open(self, port):
        text = public.ExecShell("ss -lnt | awk '{print $4}' | grep -E ':%d$'" % port)[0]
        return bool(text.strip())

    def _host(self, value):
        host = str(value or '').strip().lower().split(':')[0]
        if re.fullmatch(r'(?:\d{1,3}\.){3}\d{1,3}', host):
            parts = [int(x) for x in host.split('.')]
            if all(0 <= n <= 255 for n in parts):
                return host
            return ''
        if re.fullmatch(r'(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}', host):
            return host
        return ''

    def _safe_dir(self, path, fallback):
        raw = str(path or '').strip() or fallback
        if '\x00' in raw or '..' in raw.replace('\\', '/'):
            return ''
        raw = os.path.abspath(raw)
        if not (raw.startswith('/www/') or raw.startswith('/opt/')):
            return ''
        if raw.rstrip('/') in ('/www', '/opt', '/www/server', '/www/wwwroot'):
            return ''
        return raw

    def _program_name(self, name):
        name = str(name or '').strip()
        if re.fullmatch(r'(?:kazhan|bepusdt)_[a-z0-9_]{1,50}', name):
            return name
        return ''

    def _user_exists(self, user):
        return user in self._user_list()

    def _user_list(self):
        """与进程守护「启动用户」同一套过滤，去掉系统内部账号。"""
        text = public.readFile('/etc/passwd') or ''
        special = {
            'bin', 'daemon', 'adm', 'lp', 'shutdown', 'halt', 'mail', 'operator', 'games',
            'avahi-autoipd', 'systemd-bus-proxy', 'systemd-network', 'dbus', 'polkitd', 'tss', 'ntp',
        }
        users = []
        for line in text.splitlines():
            name = line.split(':', 1)[0]
            if name and name not in special and name not in users:
                users.append(name)
        if 'www' in users:
            users.remove('www')
            users.insert(0, 'www')
        return users

    def _shell_arg(self, path):
        return "'" + path.replace("'", "'\\''") + "'"

    def _pick_pay_port(self, requested, domain, site_dir):
        """多次部署时自动换端口。同一目录已有 .env 则沿用。"""
        existing = self._pay_port_in_env(site_dir)
        if existing:
            return existing, ''
        if requested and not self._port_taken(requested, domain):
            return requested, ''
        start = requested + 1 if requested else 8080
        port = self._free_port(start, domain)
        if not port:
            return 0, ''
        if requested:
            return port, '端口 {0} 已被占用，已改用 {1}'.format(requested, port)
        return port, '监听端口 {0}'.format(port)

    def _pay_port_in_env(self, site_dir):
        text = public.readFile(site_dir + '/.env') or ''
        matched = re.search(r'(?m)^LISTEN=127\.0\.0\.1:(\d+)\s*$', text)
        if not matched:
            return 0
        try:
            return int(matched.group(1))
        except Exception:
            return 0

    def _pay_env(self, port, site_dir):
        return (
            'LISTEN=127.0.0.1:{0}\n'
            'LOG={1}/logs\n'
            'SQLITE={1}/data/sqlite.db\n'
        ).format(port, site_dir)

    def _fetch_bepusdt(self, dest):
        arch = self._machine_arch()
        if not arch:
            return public.returnMsg(False, '只支持 amd64 / arm64')
        asset = 'linux-{0}-BEpusdt.tar.gz'.format(arch)
        direct = 'https://github.com/{0}/releases/latest/download/{1}'.format(PAY_REPO, asset)
        routes = [('github', direct)]
        for accel in RELEASE_ACCELS:
            routes.append((accel, accel.rstrip('/') + '/' + direct))
        hits = []
        lock = threading.Lock()

        def race(source, url):
            fine, ms = self._probe_head(url)
            if fine:
                with lock:
                    hits.append((ms, source, url))

        workers = [threading.Thread(target=race, args=item) for item in routes]
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join(8)
        hits.sort()
        if not hits:
            return public.returnMsg(False, '所有发行线路都不可达，请检查服务器出网')
        errors = []
        for _latency, source, url in hits:
            label = self._source_label(source)
            err, version = self._download_bepusdt(url, asset, dest)
            if not err:
                return {'status': True, 'source': source, 'version': version}
            errors.append(label + ' ' + err)
        return public.returnMsg(False, '已切换全部线路仍失败：' + '；'.join(errors))

    def _download_bepusdt(self, url, asset, dest):
        tmp = dest + '.download'
        caught = []

        class _Remember(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                caught.append(newurl)
                return urllib.request.HTTPRedirectHandler.redirect_request(self, req, fp, code, msg, headers, newurl)

        try:
            opener = urllib.request.build_opener(_Remember)
            req = urllib.request.Request(url, headers={'User-Agent': 'kazhan-panel'})
            with opener.open(req, timeout=180) as resp:
                final = resp.geturl()
                with open(tmp, 'wb') as fh:
                    while True:
                        chunk = resp.read(1024 * 64)
                        if not chunk:
                            break
                        fh.write(chunk)
        except Exception:
            if os.path.isfile(tmp):
                os.remove(tmp)
            return '下载失败', ''
        version = ''
        for candidate in caught + [final or '', url]:
            matched = re.search(r'/releases/download/(v\d+\.\d+\.\d+)/', candidate)
            if matched:
                version = matched.group(1)
                break
        if not version:
            os.remove(tmp)
            return '无法确认版本', ''
        sum_base = ''
        for candidate in caught + [final or '', url]:
            if version in candidate and '/releases/download/' in candidate:
                sum_base = candidate.split('?')[0].rsplit('/', 1)[0]
                break
        if not sum_base:
            os.remove(tmp)
            return '无法确认校验地址', ''
        sum_url = sum_base + '/BEpusdt_{0}_checksums.txt'.format(version[1:])
        digest = self._checksum_for(sum_url, asset)
        if not digest:
            os.remove(tmp)
            return '校验文件失败', ''
        actual = hashlib.sha256()
        with open(tmp, 'rb') as fh:
            while True:
                block = fh.read(1024 * 1024)
                if not block:
                    break
                actual.update(block)
        if actual.hexdigest() != digest:
            os.remove(tmp)
            return '校验失败', ''
        err = self._extract_bepusdt(tmp, dest)
        os.remove(tmp)
        if err:
            return err, ''
        if not self._chmod_binary(dest):
            return '程序权限未能设为 755', ''
        return '', version

    def _checksum_for(self, url, asset):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'kazhan-panel'})
            with urllib.request.urlopen(req, timeout=30) as resp:
                text = resp.read(1024 * 64).decode('utf-8', 'replace')
        except Exception:
            return ''
        for line in text.splitlines():
            parts = line.split()
            if len(parts) < 2 or os.path.basename(parts[-1]) != asset:
                continue
            digest = parts[0].lower()
            if re.fullmatch(r'[0-9a-f]{64}', digest):
                return digest
        return ''

    def _extract_bepusdt(self, package, dest):
        try:
            with tarfile.open(package, 'r:gz') as tar:
                picked = None
                for item in tar.getmembers():
                    if not item.isfile() or item.issym() or item.islnk():
                        continue
                    if os.path.basename(item.name) != 'bepusdt':
                        continue
                    if item.name.startswith('/') or '..' in item.name.split('/'):
                        continue
                    picked = item
                    break
                if not picked:
                    return '压缩包里没有 bepusdt'
                src = tar.extractfile(picked)
                if src is None:
                    return '压缩包里没有 bepusdt'
                with src, open(dest, 'wb') as out:
                    shutil.copyfileobj(src, out)
        except tarfile.TarError:
            return '解压失败'
        return ''

    def _read_state(self, path):
        empty = {'sites': [], 'payments': []}
        if not path or not os.path.isfile(path):
            return empty
        try:
            data = json.loads(public.readFile(path) or '{}')
        except Exception:
            return empty
        if not isinstance(data, dict):
            return empty
        sites = data.get('sites') if isinstance(data.get('sites'), list) else []
        payments = data.get('payments') if isinstance(data.get('payments'), list) else []
        return {'sites': sites, 'payments': payments}

    def _merge_rows(self, first, second):
        merged = []
        seen = set()
        for item in list(first or []) + list(second or []):
            if not isinstance(item, dict):
                continue
            key = item.get('domain') or item.get('program')
            if not key or key in seen:
                continue
            seen.add(key)
            merged.append(item)
        return merged

    def _load_config(self):
        local = self._read_state(CONFIG_FILE)
        backup = self._read_state(DATA_FILE)
        data = {
            'sites': self._merge_rows(local['sites'], backup['sites']),
            'payments': self._merge_rows(local['payments'], backup['payments']),
        }
        if not data['sites'] and not data['payments']:
            data = self._recover_from_supervisor()
        if data != local or data != backup:
            if data['sites'] or data['payments'] or local != backup:
                self._store_config(data)
        return data

    def _store_config(self, data):
        text = json.dumps({
            'sites': data.get('sites') if isinstance(data.get('sites'), list) else [],
            'payments': data.get('payments') if isinstance(data.get('payments'), list) else [],
        }, ensure_ascii=False, indent=2)
        public.writeFile(CONFIG_FILE, text)
        try:
            os.chmod(CONFIG_FILE, 0o600)
        except Exception:
            pass
        try:
            os.makedirs('/www/server/panel/data', 0o700)
            public.writeFile(DATA_FILE, text)
            os.chmod(DATA_FILE, 0o600)
        except Exception:
            pass

    def _recover_from_supervisor(self):
        """插件配置被覆盖清空时，从进程守护里已有的卡栈/收款进程补回记录。"""
        sites = []
        payments = []
        try:
            rows = json.loads(public.readFile(SUPERVISOR_DIR + '/config.json') or '[]')
        except Exception:
            rows = []
        if not isinstance(rows, list):
            return {'sites': [], 'payments': []}
        for row in rows:
            if not isinstance(row, dict):
                continue
            program = self._program_name(row.get('program'))
            if not program:
                continue
            path = str(row.get('directory') or '').rstrip('/')
            user = str(row.get('user') or 'www')
            command = str(row.get('command') or '')
            ps = str(row.get('ps') or '')
            domain = ''
            if ps.startswith('卡栈 '):
                domain = ps.split(' ', 1)[1].strip()
            elif ps.startswith('BEpusdt '):
                domain = ps.split(' ', 1)[1].strip()
            if not domain and path:
                domain = os.path.basename(path)
            item = {
                'domain': domain,
                'domains': [domain] if domain else [],
                'port': 0,
                'path': path,
                'program': program,
                'user': user,
            }
            if program.startswith('bepusdt_'):
                matched = re.search(r'--listen\s+127\.0\.0\.1:(\d+)', command)
                item['port'] = int(matched.group(1)) if matched else self._pay_port_in_env(path)
                payments.append(item)
            else:
                item['port'] = self._port_in_config(path)
                item['webroot'] = path
                item['app_dir'] = path
                sites.append(item)
        return {'sites': sites, 'payments': payments}

    def _load_sites(self):
        return self._load_config()['sites']

    def _save_sites(self, sites):
        data = self._load_config()
        data['sites'] = sites
        self._store_config(data)

    def _load_payments(self):
        return self._load_config()['payments']

    def _save_payments(self, payments):
        data = self._load_config()
        data['payments'] = payments
        self._store_config(data)

    def _tail_log(self, lines):
        if not os.path.isfile(INSTALL_LOG):
            return ''
        text = public.readFile(INSTALL_LOG) or ''
        return '\n'.join(text.splitlines()[-lines:])

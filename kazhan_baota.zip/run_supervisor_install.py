#!/www/server/panel/pyenv/bin/python
# 后台安装进程守护：带上面板已绑定的宝塔账号，再执行安装脚本。
import os
import sys

os.chdir('/www/server/panel')
sys.path.insert(0, 'class/')
sys.path.insert(0, 'plugin/kazhan')

import kazhan_main

version = sys.argv[1] if len(sys.argv) > 1 else '3.0.6'
raise SystemExit(kazhan_main.kazhan_main().run_install_job(version))
